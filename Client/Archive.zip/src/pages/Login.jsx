import React, { useState, useRef } from "react";
import { Camera, CameraAlt, Padding } from "@mui/icons-material";
import {
  Avatar,
  Button,
  Container,
  IconButton,
  Paper,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import { CameraAlt as CameraAltIcon } from "@mui/icons-material";
import { VisuallyHiddenInput } from "../components/styles/StyledComponents";
import {
  validateBio,
  validateName,
  validateUsername,
} from "../utils/Validator";

const Login = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState(null);

  const handleBlur = (e) => {
    if (e.target.value.length < 6) {
      alert("Password should be at least 6 characters long");
      // Set focus back on the password input field
      e.target.focus();
    }
  };

  return (
    <Container
      component={"main"}
      maxWidth="xs"
      sx={{
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Paper
        elevation={3}
        sx={{
          padding: 4,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        {isLogin ? (
          <>
            <Typography variant="h5">Login</Typography>
            <form style={{ width: "100%", marginTop: "1rem" }}>
              <TextField
                required
                fullWidth
                margin="normal"
                label="Username"
                variant="outlined"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />

              <TextField
                required
                fullWidth
                margin="normal"
                label="Password"
                type="password"
                variant="outlined"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />

              <Button
                variant="contained"
                color="primary"
                type="submit"
                fullWidth
                sx={{ marginTop: "1rem" }}
              >
                LOGIN
              </Button>
              <Typography textAlign={"center"} margin={"1rem"}>
                Or
              </Typography>
              <Button
                variant="text"
                color="secondary"
                fullWidth
                onClick={() => setIsLogin(false)}
              >
                Sign Up Instead
              </Button>
            </form>
          </>
        ) : (
          <>
            <Typography variant="h5">Sign Up</Typography>
            <form style={{ width: "100%", marginTop: "1rem" }}>
              <Stack position={"relative"} width={"10rem"} margin={"auto"}>
                <Avatar
                  sx={{
                    width: "10rem",
                    height: "10rem",
                    objectFit: "contain",
                  }}
                />

                <IconButton
                  sx={{
                    position: "absolute",
                    right: 0,
                    bottom: 0,
                    color: "white",
                    backgroundColor: "rgba(0,0,0,0.5)",
                    ":hover": {
                      backgroundColor: "rgba(0,0,0,0.7)",
                    },
                  }}
                  component="label"
                >
                  <>
                    <VisuallyHiddenInput type="file" />
                    <CameraAltIcon />
                  </>
                </IconButton>
              </Stack>

              <TextField
                required
                fullWidth
                margin="normal"
                label="Name"
                variant="outlined"
                value={name}
                onChange={(e) => validateName(e.target.value, setName)}
              />
              <TextField
                required
                fullWidth
                margin="normal"
                label="Username"
                variant="outlined"
                value={username}
                onChange={(e) => validateUsername(e.target.value, setUsername)}
              />
              <TextField
                required
                fullWidth
                margin="normal"
                label="Bio"
                variant="outlined"
                value={bio}
                onChange={(e) => validateBio(e.target.value, setBio)}
              />
              <TextField
                required
                fullWidth
                margin="normal"
                label="Password"
                type="password"
                variant="outlined"
                value={password}
                onBlur={(e) => {
                  if (password.length < 6) {
                    alert("Password should be at least 6 characters long");
                    e.preventDefault();
                    setPassword("");
                    e.target.focus();
                  }
                }}
                onChange={(e) => setPassword(e.target.value)}
              />

              <Button
                variant="contained"
                color="primary"
                type="submit"
                fullWidth
                sx={{ marginTop: "1rem" }}
              >
                SIGN UP
              </Button>
              <Typography textAlign={"center"} margin={"1rem"}>
                Or
              </Typography>
              <Button
                variant="text"
                color="secondary"
                fullWidth
                onClick={() => setIsLogin(true)}
              >
                Login Instead
              </Button>
            </form>
          </>
        )}
      </Paper>
    </Container>
  );
};

export default Login;
