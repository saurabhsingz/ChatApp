import React from 'react'

const Groups = () => {
  return (
    <div>Groups</div>
  )
}

export default Groups