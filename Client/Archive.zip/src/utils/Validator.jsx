export const validateName = (name, setName) => {
  const nameRegex = /^[A-Za-z]+([-']?[A-Za-z]+)*$/;

  // Check if the name matches the regex pattern
  if (!name.match(nameRegex)) {
    window.alert("Invlaide name!! Please enter a valid name");
    setName("");
  } else {
    setName(name);
  }
};
export const validateUsername = (username, setUsername) => {
  const usernameRegex = /^[A-Za-z0-9]+([-']?[A-Za-z0-9]+)*$/;

  // Check if the username matches the regex pattern
  if (!username.match(usernameRegex)) {
    window.alert("Invlaide username!! Please enter a valid username");
    setUsername("");
  } else {
    setUsername(username);
  }
};

export const validateBio = (bio, setBio) => {
  // Check if the bio is not empty
  if (bio.length > 30) {
    window.alert("Length of Bio should be lesser than 30 characters");
  } else {
    setBio(bio);
  }
};
